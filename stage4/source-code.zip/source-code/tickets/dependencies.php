<?php session_start();?>
 <!-- CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css?version=1.0">

<!-- javascript -->
    <script  type="text/javascript" src="../js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="../js/jquery-3.6.0.min.js"></script>
    <script  type="text/javascript" src="qr/qrcode.js"></script>
    <script  type="text/javascript" src="../js/main.js?version=1.0"></script>


<!-- MetaTAGS -->
     <meta charset="utf-8">

